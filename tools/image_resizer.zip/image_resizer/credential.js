//google api credentials change from here
// const projectId = "imageresize-279714";
const projectId = "384916262889";
// const APIKey = "AIzaSyD-rzafct_eLiv4r1qoghLwjnafX_B9DoA";
const APIKey = "AIzaSyAww_Wl1E3Xvn1z4bVh4BZgmdJt80Hu4iQ";
// const clientId = "694731059848-t1aenfhh6toph5le7eab4k67ftk7sl0f.apps.googleusercontent.com";
const clientId = "384916262889-8a7lhm8mdtkq90orc3botm3d4t6s8b1c.apps.googleusercontent.com";
//dropbox api credentials change
// var scope = ['https://www.googleapis.com/auth/drive'];
var scope = ['https://www.googleapis.com/auth/drive.file'];
var pickerApiLoaded = false;
var oauthToken;

//dropbox api credentials change from here
var accessToken = "HbG_6O9ZxpAAAAAAAAAESJ0dIlZB5k-1npHPBf0GuQUHmiX6BtXkkiVYmYO6-5hT-mA6";
//var dropBoxAppKey = "t5h6ylcivuzis7t";